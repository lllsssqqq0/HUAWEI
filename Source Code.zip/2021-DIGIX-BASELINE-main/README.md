# 2021-DIGIX-BASELINE
2021 huawei DIGIX competition baseline
