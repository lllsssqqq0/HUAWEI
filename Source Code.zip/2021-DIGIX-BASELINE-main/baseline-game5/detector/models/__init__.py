from .detectors import OCR_DETECTOR
from .loss import CRITERION
from .scheduler import LR_Scheduler_Head