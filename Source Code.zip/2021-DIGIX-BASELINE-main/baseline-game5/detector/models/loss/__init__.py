from .dice_loss import DiceLoss

CRITERION = {
    'dice_loss': DiceLoss,
}