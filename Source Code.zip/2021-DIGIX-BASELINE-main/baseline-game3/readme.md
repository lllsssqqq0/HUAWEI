1. Step 1: Use gen_record.py to generate tfrecord data. The generated tfrecord data can also be directly used.
2. Step 2: Use essm.py to train the model.
3. Use predict.py to predict the result.